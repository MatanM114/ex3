/******************
Name:
ID:
Assignment: ex3
*******************/

#include <stdio.h>

#define NUM_OF_BRANDS 5
#define BRANDS_NAMES 15
#define NUM_OF_TYPES 4
#define TYPES_NAMES 10
#define DAYS_IN_YEAR 365
#define addOne  1
#define addAll  2
#define stats  3
#define print  4
#define insights  5
#define deltas  6
#define done  7
#define TOYOGA 0
#define HYUNNIGHT 1
#define MAZDUH 2
#define FOLKSVEGAN 3
#define KEYYUH 4
#define SUV 0
#define SEDAN 1
#define COUPE 2
#define GT 3

char brands[NUM_OF_BRANDS][BRANDS_NAMES] = {"Toyoga", "HyunNight", "Mazduh", "FolksVegan", "Key-Yuh"};
char types[NUM_OF_TYPES][TYPES_NAMES] = {"SUV", "Sedan", "Coupe", "GT"};


void printMenu();

void initializeCube(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int daysInYear, int numOfBrands,
                    int numOfTypes);

void insertData(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand);

void printBrand(int brand);

void printType(int type);

int dayTotalSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

int getBrandDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand, int numOfTypes);

int bestSoldBrand(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

int getTypeDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int type, int numOfBrands);

int bestSoldType(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

void printSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand);

int getBrandOverallSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand,
                         int numOfTypes);

int getTypeOverallSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int type,
                        int numOfBrands);

int bestSellingBrandOverall(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                            int numOfTypes);

int bestSellingTypeOverall(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                           int numOfTypes);

int mostProfitableDay(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                      int numOfTypes);

void printAverageDelta(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand, int numOfTypes);


int main() {
    int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES];
    initializeCube(cube, DAYS_IN_YEAR, NUM_OF_BRANDS, NUM_OF_TYPES);
    int currentDay = 0;
    int choice;
    printMenu();
    scanf("%d", &choice);
    while (choice != done) {
        switch (choice) {
            case addOne:
                //...
                break;
            case addAll:
                int isDayFilled = 0;
                int isBrandFilled[NUM_OF_BRANDS] = {0, 0, 0, 0, 0};
                do {
                    printf("No data for brands ");
                    for (int i = 0; i < NUM_OF_BRANDS; i++) {
                        if (!isBrandFilled[i]) {
                            printBrand(i);
                            printf(" ");
                        }
                    }
                    printf("\nPlease complete the data\n");

                    int chosenBrand;
                    scanf(" %d", &chosenBrand);
                    if (chosenBrand < TOYOGA || chosenBrand > KEYYUH) {
                        printf("This brand is not valid");
                        continue;
                    }

                    insertData(cube, currentDay, chosenBrand);
                    isBrandFilled[chosenBrand] = 1;

                    isDayFilled = 1;
                    for (int i = 0; i < NUM_OF_BRANDS; i++) {
                        if (cube[currentDay][i][0] == -1) {
                            isDayFilled = 0;
                            break;
                        }
                    }
                } while (isDayFilled == 0);
                currentDay++;
                break;


            case stats:
                printf("What day would you like to analyze?\n");
                int chosenDay;
                scanf(" %d", &chosenDay);
                while (chosenDay - 1 < 0 || chosenDay - 1 >= currentDay) {
                    printf("Please enter a valid day.\nWhat day would you like to analyze?\n");
                    scanf(" %d", &chosenDay);
                }
                int indexDay = chosenDay - 1;

                printf("In day number %d:\n", chosenDay);
                printf("The sales total was %d\n", dayTotalSales(cube, indexDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("The best sold brand with ");
                printf("%d sales was ", getBrandDaySales(cube, indexDay,
                                                         bestSoldBrand(cube, indexDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                         NUM_OF_TYPES));
                printBrand(bestSoldBrand(cube, indexDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("\n");
                printf("The best sold type with ");
                printf("%d sales was ", getTypeDaySales(cube, indexDay,
                                                        bestSoldType(cube, indexDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                        NUM_OF_BRANDS));
                printType(bestSoldType(cube, indexDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("\n\n");
                break;

            case print:
                printf("*****************************************\n\n");
                printf("Sales for Toyoga:\n");
                printSales(cube, currentDay, TOYOGA);
                printf("Sales for HyunNight:\n");
                printSales(cube, currentDay, HYUNNIGHT);
                printf("Sales for Mazduh:\n");
                printSales(cube, currentDay, MAZDUH);
                printf("Sales for FolksVegan:\n");
                printSales(cube, currentDay, FOLKSVEGAN);
                printf("Sales for Key-Yuh:\n");
                printSales(cube, currentDay, KEYYUH);
                printf("\n*****************************************\n");
                break;

            case insights:
                printf("The best-selling brand overall is ");
                printBrand(bestSellingBrandOverall(cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf(": %d$\n", getBrandOverallSales(cube, currentDay,
                                                       bestSellingBrandOverall(
                                                           cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                       NUM_OF_TYPES));
                printf("The best-selling type of car is ");
                printType(bestSellingTypeOverall(cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf(": %d$\n", getTypeOverallSales(cube, currentDay,
                                                      bestSellingTypeOverall(
                                                          cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                      NUM_OF_BRANDS));
                printf("The most profitable day was day number ");
                printf("%d", mostProfitableDay(cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES) + 1);
                printf(": %d$\n", dayTotalSales(cube, mostProfitableDay(cube, currentDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                NUM_OF_BRANDS, NUM_OF_TYPES));
                break;

            case deltas:
                printf("Brand: Toyoga, Average Delta: ");
                printAverageDelta(cube, currentDay, TOYOGA, NUM_OF_TYPES);
                printf("Brand: HyunNight, Average Delta: ");
                printAverageDelta(cube, currentDay, HYUNNIGHT, NUM_OF_TYPES);
                printf("Brand: Mazduh, Average Delta: ");
                printAverageDelta(cube, currentDay, MAZDUH, NUM_OF_TYPES);
                printf("Brand: FolksVegan, Average Delta: ");
                printAverageDelta(cube, currentDay, FOLKSVEGAN, NUM_OF_TYPES);
                printf("Brand: Key-Yuh, Average Delta: ");
                printAverageDelta(cube, currentDay, KEYYUH, NUM_OF_TYPES);
                break;


            default:
                printf("Invalid input\n");
        }
        printMenu();
        scanf("%d", &choice);
    }
    printf("Goodbye!\n");
    return 0;
}


void printMenu() {
    printf("Welcome to the Cars Data Cube! What would you like to do?\n"
        "1.Enter Daily Data For A Brand\n"
        "2.Populate A Day Of Sales For All Brands\n"
        "3.Provide Daily Stats\n"
        "4.Print All Data\n"
        "5.Provide Overall (simple) Insights\n"
        "6.Provide Average Delta Metrics\n"
        "7.exit\n");
}

void initializeCube(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int daysInYear, int numOfBrands,
                    int numOfTypes) {
    for (int i = 0; i < daysInYear; i++) {
        for (int j = 0; j < numOfBrands; j++) {
            for (int k = 0; k < numOfTypes; k++) {
                cube[i][j][k] = -1;
            }
        }
    }
}

void insertData(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand) {
    scanf(" %d", &cube[currentDay][brand][0]);
    scanf(" %d", &cube[currentDay][brand][1]);
    scanf(" %d", &cube[currentDay][brand][2]);
    scanf(" %d", &cube[currentDay][brand][3]);
}

void printBrand(int brand) {
    switch (brand) {
        case 0:
            printf("Toyoga");
            break;
        case 1:
            printf("HyunNight");
            break;
        case 2:
            printf("Mazduh");
            break;
        case 3:
            printf("FolksVegan");
            break;
        case 4:
            printf("Key-Yuh");
            break;
    }
}

void printType(int type) {
    switch (type) {
        case 0:
            printf("SUV");
            break;
        case 1:
            printf("SEDAN");
            break;
        case 2:
            printf("COUPE");
            break;
        case 3:
            printf("GT");
            break;
    }
}

int dayTotalSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int totalSales = 0;
    for (int i = 0; i < numOfBrands; i++) {
        totalSales += getBrandDaySales(cube, day, i, numOfTypes);
    }
    return totalSales;
}

int getBrandDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand, int numOfTypes) {
    int brandSales = 0;
    for (int i = 0; i < numOfTypes; i++) {
        brandSales += cube[day][brand][i];
    }
    return brandSales;
}

int bestSoldBrand(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int bestSoldBrand = 0;
    for (int i = 0; i < numOfBrands; i++) {
        if (getBrandDaySales(cube, day, i, numOfTypes) > getBrandDaySales(cube, day, bestSoldBrand, numOfTypes)) {
            bestSoldBrand = i;
        }
    }
    return bestSoldBrand;
}

int getTypeDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int type, int numOfBrands) {
    int typeSales = 0;
    for (int i = 0; i < numOfBrands; i++) {
        typeSales += cube[day][i][type];
    }
    return typeSales;
}

int bestSoldType(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int bestSoldType = 0;
    for (int i = 0; i < numOfTypes; i++) {
        if (getTypeDaySales(cube, day, i, numOfBrands) > getTypeDaySales(cube, day, bestSoldType, numOfBrands)) {
            bestSoldType = i;
        }
    }
    return bestSoldType;
}

void printSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand) {
    for (int i = 0; i < currentDay; i++) {
        printf("Day %d- ", i + 1);
        printf("SUV: %d ", cube[i][brand][0]);
        printf("Sedan: %d ", cube[i][brand][1]);
        printf("Coupe: %d ", cube[i][brand][2]);
        printf("GT: %d ", cube[i][brand][3]);
        printf("\n");
    }
}

int getBrandOverallSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand,
                         int numOfTypes) {
    int brandOverallSales = 0;
    for (int i = 0; i < currentDay; i++) {
        brandOverallSales += getBrandDaySales(cube, i, brand, numOfTypes);
    }
    return brandOverallSales;
}

int getTypeOverallSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int type,
                        int numOfBrands) {
    int typeOverallSales = 0;
    for (int i = 0; i < currentDay; i++) {
        typeOverallSales += getTypeDaySales(cube, i, type, numOfBrands);
    }
    return typeOverallSales;
}

int bestSellingBrandOverall(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                            int numOfTypes) {
    int bestSellingBrand = 0;
    for (int i = 0; i < numOfBrands; i++) {
        if (getBrandOverallSales(cube, currentDay, i, numOfTypes) > getBrandOverallSales(
                cube, currentDay, bestSellingBrand, numOfTypes)) {
            bestSellingBrand = i;
        }
    }
    return bestSellingBrand;
}

int bestSellingTypeOverall(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                           int numOfTypes) {
    int bestSellingType = 0;
    for (int i = 0; i < numOfTypes; i++) {
        if (getTypeOverallSales(cube, currentDay, i, numOfBrands) > getTypeOverallSales(
                cube, currentDay, bestSellingType, numOfBrands)) {
            bestSellingType = i;
        }
    }
    return bestSellingType;
}

int mostProfitableDay(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int numOfBrands,
                      int numOfTypes) {
    int mostProfitableDay = 0;
    for (int i = 0; i < currentDay; i++) {
        if (dayTotalSales(cube, i, numOfBrands, numOfTypes) > dayTotalSales(
                cube, mostProfitableDay, numOfBrands, numOfTypes)) {
            mostProfitableDay = i;
        }
    }
    return mostProfitableDay;
}

void printAverageDelta(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int currentDay, int brand, int numOfTypes) {
    int first = getBrandDaySales(cube, 0, brand, numOfTypes);
    int last = getBrandDaySales(cube, currentDay - 1, brand, numOfTypes);
    int Delta = last - first;
    float averageDelta = (float) Delta / (currentDay - 1);
    printf("%f\n", averageDelta);
}
