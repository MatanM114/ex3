/******************
Name:
ID:
Assignment: ex3
*******************/

#include <stdio.h>

#define NUM_OF_BRANDS 5
#define BRANDS_NAMES 15
#define NUM_OF_TYPES 4
#define TYPES_NAMES 10
#define DAYS_IN_YEAR 365
#define addOne  1
#define addAll  2
#define stats  3
#define print  4
#define insights  5
#define deltas  6
#define done  7
#define TOYOGA 0
#define HYUNNIGHT 1
#define MAZDUH 2
#define FOLKSVEGAN 3
#define KEYYUH 4
#define SUV 0
#define SEDAN 1
#define COUPE 2
#define GT 3

char brands[NUM_OF_BRANDS][BRANDS_NAMES] = {"Toyoga", "HyunNight", "Mazduh", "FolksVegan", "Key-Yuh"};
char types[NUM_OF_TYPES][TYPES_NAMES] = {"SUV", "Sedan", "Coupe", "GT"};


void printMenu();

void initializeCube(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int daysInYear, int numOfBrands,
                    int numOfTypes);

void insertData(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand);

void printBrand(int brand);

void printType(int type);

int dayTotalSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

int getBrandDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand, int numOfTypes);

int bestSoldBrand(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

int getTypeDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int type, int numOfBrands);

int bestSoldType(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes);

void printSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand);

int main() {
    int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES];
    initializeCube(cube, DAYS_IN_YEAR, NUM_OF_BRANDS, NUM_OF_TYPES);
    int day = 0;
    int choice;
    printMenu();
    scanf("%d", &choice);
    while (choice != done) {
        switch (choice) {
            case addOne:
                //...
                break;
            case addAll:
                int isDayFilled = 0;
                int isBrandFilled[NUM_OF_BRANDS];
                do {
                    printf("No data for brands ");
                    for (int i = 0; i < NUM_OF_BRANDS; i++) {
                        if (!isBrandFilled[i]) {
                            printBrand(i);
                            printf(" ");
                        }
                    }
                    printf("\nPlease complete the data\n");

                    int chosenBrand;
                    scanf(" %d", &chosenBrand);
                    if (chosenBrand < TOYOGA || chosenBrand > KEYYUH) {
                        printf("This brand is not valid");
                        continue;
                    }

                    insertData(cube, day, chosenBrand);
                    isBrandFilled[chosenBrand] = 1;

                    isDayFilled = 1;
                    for (int i = 0; i < NUM_OF_BRANDS; i++) {
                        if (cube[day][i][0] == -1) {
                            isDayFilled = 0;
                            break;
                        }
                    }
                } while (isDayFilled == 0);
                day++;
                break;

            case stats:
                printf("What day would you like to analyze?\n");
                int chosenDay;
                scanf(" %d", &chosenDay);
                while (chosenDay < 0 || chosenDay >= day) {
                    printf("Please enter a valid day.\nWhat day would you like to analyze?\n");
                    scanf(" %d", &chosenDay);
                }

                printf("In day number %d\n", chosenDay);
                printf("The sales total was %d\n", dayTotalSales(cube, chosenDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("The best sold brand with ");
                printf("%d sales was ", getBrandDaySales(cube, chosenDay,
                                                         bestSoldBrand(cube, chosenDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                         NUM_OF_BRANDS));
                printBrand(bestSoldBrand(cube, chosenDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("\n");
                printf("The best sold type with ");
                printf("%d sales was ", getTypeDaySales(cube, chosenDay,
                                                        bestSoldType(cube, chosenDay, NUM_OF_BRANDS, NUM_OF_TYPES),
                                                        NUM_OF_BRANDS));
                printType(bestSoldType(cube, chosenDay, NUM_OF_BRANDS, NUM_OF_TYPES));
                printf("\n\n");
                break;

            case print:
                printf("*****************************************\n\n");
                printf("Sales for Toyoga:\n");
                printSales(cube, day, TOYOGA);
                printf("Sales for Hyunnight:\n");
                printSales(cube, day, HYUNNIGHT);
                printf("Sales for Mazduh:\n");
                printSales(cube, day, MAZDUH);
                printf("Sales for FolksVegan:\n");
                printSales(cube, day, FOLKSVEGAN);
                printf("Sales for Key-Yuh:\n");
                printSales(cube, day, KEYYUH);
                printf("\n*****************************************\n");
                break;


            default:
                printf("Invalid input\n");
        }
        printMenu();
        scanf("%d", &choice);
    }
    printf("Goodbye!\n");
    return 0;
}


void printMenu() {
    printf("Welcome to the Cars Data Cube! What would you like to do?\n"
        "1.Enter Daily Data For A Brand\n"
        "2.Populate A Day Of Sales For All Brands\n"
        "3.Provide Daily Stats\n"
        "4.Print All Data\n"
        "5.Provide Overall (simple) Insights\n"
        "6.Provide Average Delta Metrics\n"
        "7.exit\n");
}

void initializeCube(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int daysInYear, int numOfBrands,
                    int numOfTypes) {
    for (int i = 0; i < daysInYear; i++) {
        for (int j = 0; j < numOfBrands; j++) {
            for (int k = 0; k < numOfTypes; k++) {
                cube[i][j][k] = -1;
            }
        }
    }
}

void insertData(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand) {
    scanf(" %d", &cube[day][brand][0]);
    scanf(" %d", &cube[day][brand][1]);
    scanf(" %d", &cube[day][brand][2]);
    scanf(" %d", &cube[day][brand][3]);
}

void printBrand(int brand) {
    switch (brand) {
        case 0:
            printf("Toyoga");
            break;
        case 1:
            printf("Hyunnight");
            break;
        case 2:
            printf("Mazduh");
            break;
        case 3:
            printf("FolksVegan");
            break;
        case 4:
            printf("Keyyuh");
            break;
    }
}

void printType(int type) {
    switch (type) {
        case 0:
            printf("SUV");
            break;
        case 1:
            printf("SEDAN");
            break;
        case 2:
            printf("COUPE");
            break;
        case 3:
            printf("GT");
            break;
    }
}

int dayTotalSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int totalSales = 0;
    for (int i = 0; i < numOfBrands; i++) {
        totalSales += getBrandDaySales(cube, day, i, numOfTypes);
    }
    return totalSales;
}

int getBrandDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand, int numOfTypes) {
    int brandSales = 0;
    for (int i = 0; i < numOfTypes; i++) {
        brandSales += cube[day][brand][i];
    }
    return brandSales;
}

int bestSoldBrand(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int bestSoldBrand = 0;
    for (int i = 0; i < numOfBrands; i++) {
        if (getBrandDaySales(cube, day, i, numOfTypes) > getBrandDaySales(cube, day, bestSoldBrand, numOfTypes)) {
            bestSoldBrand = i;
        }
    }
    return bestSoldBrand;
}

int getTypeDaySales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int type, int numOfBrands) {
    int typeSales = 0;
    for (int i = 0; i < numOfBrands; i++) {
        typeSales += cube[day][i][type];
    }
    return typeSales;
}

int bestSoldType(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int numOfBrands, int numOfTypes) {
    int bestSoldType = 0;
    for (int i = 0; i < numOfTypes; i++) {
        if (getTypeDaySales(cube, day, i, numOfBrands) > getTypeDaySales(cube, day, bestSoldType, numOfBrands)) {
            bestSoldType = i;
        }
    }
    return bestSoldType;
}

void printSales(int cube[DAYS_IN_YEAR][NUM_OF_BRANDS][NUM_OF_TYPES], int day, int brand) {
    for (int i = 0; i < day; i++) {
        printf("Day %d- ", i + 1);
        printf("SUV: %d ", cube[i][brand][0]);
        printf("Sedan: %d ", cube[i][brand][1]);
        printf("Coupe: %d ", cube[i][brand][2]);
        printf("GT: %d ", cube[i][brand][3]);
        printf("\n");
    }
}